<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePaymentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('store_id')->nullable();
            $table->unsignedBigInteger('charge_id')->nullable();
            $table->unsignedBigInteger('api_client_id')->nullable();
            $table->string('name')->nullable();
            $table->integer('price')->nullable();
            $table->boolean('test')->nullable();
            $table->string('status')->nullable();
            $table->string('type')->nullable();
            $table->string('return_url', 255)->nullable();
            $table->text('confirm_url')->nullable();
            $table->unsignedInteger('plan_id')->nullable();
            $table->datetime('activated_on')->nullable();
            $table->datetime('billing_on')->nullable();
            $table->datetime('cancelled_on')->nullable();
            $table->string('terms')->nullable();
            $table->integer('trial_days')->nullable();
            $table->datetime('trial_ends_on')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('payments');
    }
}
