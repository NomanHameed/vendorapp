<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStylesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('styles', function (Blueprint $table) {
            $table->id();
            $table->integer('styleID')->nullable();
            $table->integer('partNumber')->nullable();
            $table->string('brandName')->nullable();
            $table->string('styleName')->nullable();
            $table->string('uniqueStyleName')->nullable();
            $table->string('title')->nullable();
            $table->text('description')->nullable();
            $table->string('baseCategory')->nullable();
            $table->string('categories')->nullable();
            $table->integer('catalogPageNumber')->nullable();
            $table->string('newStyle')->nullable();
            $table->integer('comparableGroup')->nullable();
            $table->integer('companionGroup')->nullable();
            $table->string('brandImage')->nullable();
            $table->string('styleImage')->nullable();
            $table->string('prop65Chemicals')->nullable();
            $table->string('noeRetailing')->nullable();
            $table->string('boxRequired')->nullable();
            // $table->string('product_id')->nullable();
            $table->text('product_json')->nullable();
            $table->boolean('canada')->nullable();
            $table->boolean('usa')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('styles');
    }
}
